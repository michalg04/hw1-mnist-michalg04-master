from __future__ import absolute_import
import matplotlib as mpl
import matplotlib.pyplot as plt
mpl.use('tkagg')
import numpy as np
from preprocess import get_data
from preprocess import batch


class Model:
    """
    This model class will contain the architecture for
    your single layer Neural Network for classifying MNIST with 
    batched learning. Please implement the TODOs for the entire 
    model but do not change the method and constructor arguments. 
    Make sure that your Model class works with multiple batch 
    sizes. Additionally, please exclusively use NumPy and 
    Python built-in functions for your implementation.
    """

    def __init__(self):
        # TODO: Initialize all hyperparametrs
        self.input_size = 784 # Size of image vectors
        self.num_classes = 10 # Number of classes/possible labels
        self.batch_size = 100
        self.learning_rate = 0.5

        # TODO: Initialize weights and biases
        # These are the weights wi,j and the biases bj where 0≤i≤783 and 0≤j≤9. All parameters should be initialized to 0.
        self.W = np.zeros((self.input_size, self.num_classes))
        self.b = np.zeros((1, self.num_classes))



    def call(self, inputs):
        """
        Does the forward pass on an batch of input images.
        :param inputs: normalized (0.0 to 1.0) batch of images,
                       (batch_size x 784) (2D), where batch can be any number.
        :return: probabilities, probabilities for each class per image # (batch_size x 10)
        """
        # TODO: Write the forward pass logic for your model
        #(100, 784) x (784, 10)

        a = np.matmul(inputs, self.W) + self.b

        #should return shape (100,10)
        # TODO: Calculate, then return, the probability for each class per image using the Softmax equation

        e_x = np.exp(a)
        div = np.sum(e_x, axis=1, keepdims=True)
        probs = e_x / div
        #print(np.sum(probs, axis = 1))
        return probs

    
    def loss(self, probabilities, labels):
        """
        Calculates the model cross-entropy loss after one forward pass.
        Loss should be decreasing with every training loop (step). 
        NOTE: This function is not actually used for gradient descent 
        in this assignment, but is a sanity check to make sure model 
        is learning.
        :param probabilities: matrix that contains the probabilities 
        of each class for each image
        :param labels: the true batch labels
        :return: average loss per batch element (float)
        """
        # TODO: calculate average cross entropy loss for a batch

        E = -np.log(probabilities[range(self.batch_size), labels])
        avg = np.mean(E)

        return avg
    
    def back_propagation(self, inputs, probabilities, labels):
        """
        Returns the gradients for model's weights and biases 
        after one forward pass and loss calculation. The learning 
        algorithm for updating weights and biases mentioned in 
        class works for one image, but because we are looking at 
        batch_size number of images at each step, you should take the
        average of the gradients across all images in the batch.
        :param inputs: batch inputs (a batch of images)
        :param probabilities: matrix that contains the probabilities of each 
        class for each image
        :param labels: true labels
        :return: gradient for weights,and gradient for biases
        """
        # TODO: calculate the gradients for the weights and the gradients for the bias with respect to average loss
        """
        #delta_W = np.zeros((self.input_size, self.num_classes))
        #delta_b = np.zeros((self.num_classes))
        y_hot = np.zeros((self.batch_size, self.num_classes))
        for i in range(self.batch_size):
            correct_label = labels[i]
            y_hot[i][correct_label] = 1
        """

        y_hot = np.eye(self.num_classes)[labels]
        diff = probabilities - y_hot
        # (10, 784) X (784,100) -> (10,100) -> (100,10)

        #delta_W = (np.matmul(diff.T, inputs)).T

        delta_W = np.matmul(inputs.T, diff) / self.batch_size
        delta_b = np.sum(diff, axis=0, keepdims=True) / self.batch_size

        """
        for k in range(len(inputs)):
            input = inputs[k]
            label = labels[k]
            #probabilities = self.call(input)
            for j in range(len(probabilities)):
                if j == label:
                    y_j = 1
                else:
                    y_j = 0
                for i in range(len(input)):
                    delta_W[j][i] += self.learning_rate * (y_j - probabilities[k][j]) * (input[i])
                delta_b += self.learning_rate * (y_j - probabilities[j])
        """

        return delta_W, delta_b


    def accuracy(self, probabilities, labels):
        """
        Calculates the model's accuracy by comparing the number 
        of correct predictions with the correct answers.
        :param probabilities: result of running model.call() on test inputs
        :param labels: test set labels
        :return: Float (0,1) that contains batch accuracy
        """
        # TODO: calculate the batch accuracy
        acc = np.mean(np.argmax(probabilities, axis=1) == labels)
        return acc


    def gradient_descent(self, gradW, gradB):
        '''
        Given the gradients for weights and biases, does gradient 
        descent on the Model's parameters.
        :param gradW: gradient for weights
        :param gradB: gradient for biases
        :return: None
        '''
        # TODO: change the weights and biases of the model to descent the gradient

        self.W += -self.learning_rate * gradW
        self.b += -self.learning_rate * gradB


    
def train(model, train_inputs, train_labels):
    '''
    Trains the model on all of the inputs and labels.
    :param model: the initialized model to use for the forward 
    pass and backward pass
    :param train_inputs: train inputs (all inputs to use for training)
    :param train_inputs: train labels (all labels to use for training)
    :return: None
    '''

    batch_inputs, batch_labels = batch(model.batch_size, train_inputs, train_labels)
    losses = [0] * np.array(batch_inputs).shape[0] #np.zeros

    for i in range(np.array(batch_inputs).shape[0]):
        batch_x = batch_inputs[i]
        batch_y = batch_labels[i]
        probs = model.call(batch_x)
        gradW, gradB = model.back_propagation(batch_x, probs, batch_y)
        model.gradient_descent(gradW, gradB)

        # TODO: Iterate over the training inputs and labels, in model.batch_size increments
        # TODO: For every batch, compute then descend the gradients for the model's weights
        # Optional TODO: Call visualize_loss and observe the loss per batch as the model trains.
        losses[i] = model.loss(probs, batch_y)



    #print(losses)

    #visualize_loss(losses)


def test(model, test_inputs, test_labels):
    """
    Tests the model on the test inputs and labels. For this assignment, 
    the inputs should be the entire test set, but in the future we will
    ask you to batch it instead.
    :param test_inputs: MNIST test data (all images to be tested)
    :param test_labels: MNIST test labels (all corresponding labels)
    :return: accuracy - Float (0,1)
    """
    # TODO: Iterate over the testing inputs and labels
    # TODO: Return accuracy across testing set
    probs = model.call(test_inputs)
    acc = model.accuracy(probs, test_labels)
    return acc

def visualize_loss(losses):
    """
    Uses Matplotlib to visualize loss per batch. Call this in train().
    When you observe the plot that's displayed, think about:
    1. What does the plot demonstrate or show?
    2. How long does your model need to train to reach roughly its best accuracy so far, 
    and how do you know that?
    Optionally, add your answers to README!
    param losses: an array of loss value from each batch of train

    NOTE: DO NOT EDIT
    
    :return: doesn't return anything, a plot should pop-up
    """
    x = np.arange(1, len(losses)+1)
    plt.xlabel('i\'th Batch')
    plt.ylabel('Loss Value')
    plt.title('Loss per Batch')
    plt.plot(x, losses)
    plt.show()

def visualize_results(image_inputs, probabilities, image_labels):
    """
    Uses Matplotlib to visualize the results of our model.
    :param image_inputs: image data from get_data()
    :param probabilities: the output of model.call()
    :param image_labels: the labels from get_data()

    NOTE: DO NOT EDIT

    :return: doesn't return anything, a plot should pop-up 
    """
    images = np.reshape(image_inputs, (-1, 28, 28))
    predicted_labels = np.argmax(probabilities, axis=1)
    num_images = images.shape[0]

    fig, axs = plt.subplots(ncols=num_images)
    fig.suptitle("PL = Predicted Label\nAL = Actual Label")

    for ind, ax in enumerate(axs):
        ax.imshow(images[ind], cmap="Greys")
        ax.set(title="PL: {}\nAL: {}".format(predicted_labels[ind], image_labels[ind]))
        plt.setp(ax.get_xticklabels(), visible=False)
        plt.setp(ax.get_yticklabels(), visible=False)
        ax.tick_params(axis='both', which='both', length=0)
    plt.show()

def main():
    '''
    Read in MNIST data, initialize your model, and train and test your model 
    for one epoch. The number of training steps should be your the number of 
    batches you run through in a single epoch. You should receive a final accuracy on the testing examples of > 80%.
    :return: None
    '''

    # TODO: load MNIST train and test examples into train_inputs, train_labels, test_inputs, test_labels
    train_inputs, train_labels = get_data("/Users/michal/Downloads/hw1-mnist-michalg04-master/data/train-images-idx3-ubyte.gz",
             "/Users/michal/Downloads/hw1-mnist-michalg04-master/data/train-labels-idx1-ubyte.gz", 60000)

    test_inputs, test_labels = get_data("/Users/michal/Downloads/hw1-mnist-michalg04-master/data/t10k-images-idx3-ubyte.gz",
             "/Users/michal/Downloads/hw1-mnist-michalg04-master/data/t10k-labels-idx1-ubyte.gz", 10000)
    # TODO: Create Model
    model = Model()

    # TODO: Train model by calling train() ONCE on all data
    train(model, train_inputs, train_labels)
    # TODO: Test the accuracy by calling test() after running train()
    acc = test(model,test_inputs, test_labels)
    print(acc)
    # TODO: Visualize the data by using visualize_results()
    probs = model.call(test_inputs)
    #visualize_results(test_inputs, probs, test_labels)


if __name__ == '__main__':
    main()
